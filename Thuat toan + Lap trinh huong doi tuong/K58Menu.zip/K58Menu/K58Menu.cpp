#include"K58Menu.h"
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

void K58Menu::ShowMenu()
{
    while(1)
    {
        cout <<"\r\nMenu quan ly thu vien:\r\n1.Them sach\
                                    \r\n2.Hien danh sach sach co the muon\
                                    \r\n3.Cho muon sach\
                                    \r\n4.Tra sach\
                                    \r\n5.Tim kiem theo ten sach\
                                    \r\n6.Ket thuc\r\nChon:";
        int m_selected;
        cin >>m_selected;
       	system("cls");		// thay cho ham clrscr()
        switch(m_selected)
        {
            case 1: AddItem();
		            getch();
                    break;
            case 2: ShowListItems();
	                getch();
                    break;
            case 3: HideItem();
                    getch();
                    break;
            case 4: ShowItem();
                    getch();
                    break;
            case 5: SearchItem();
                    getch();
                    break;
            case 6: exit(0);
                    break;
            default:           
                cout <<"Hay nhap lai:\r\n";
        }
   }
}

void K58Menu::AddItem()
{
    cout<< "AddItem()";
}

void K58Menu::ShowListItems()
{
    cout<< "ShowListItems()";
}

void K58Menu::HideItem()
{
    cout<< "HideItem()";
}

void K58Menu::ShowItem()
{
    cout<< "ShowItem()";
}

bool K58Menu::SearchItem()
{
    cout<< "SearchItem()";
}

