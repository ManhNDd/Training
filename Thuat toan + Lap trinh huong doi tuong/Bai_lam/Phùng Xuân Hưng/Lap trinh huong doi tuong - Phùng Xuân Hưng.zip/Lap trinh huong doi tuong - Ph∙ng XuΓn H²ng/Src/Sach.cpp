#include "Sach.h"
#include<iostream>
#include<iomanip>
#include<vector>
#include<conio.h>

#define MAX 100

vector<Sach> arrSach;
int arrFlag[MAX], index = 0;

Sach::Sach()
{

}

Sach::Sach(string tensach, string tacgia, string nhaxuatban) 
{
	strTenSach = tensach;
	strTacGia = tacgia;
	strNhaXuatBan = nhaxuatban;
}

string Sach::getTenSach()
{
	return strTenSach;
}

string Sach::getTacGia()
{
	return strTacGia;
}

string Sach::getNhaXuatBan()
{
	return strNhaXuatBan;
}

void Sach::setTenSach(string tensach)
{
	strTenSach = tensach;
}

void Sach::setTacGia(string tacgia)
{
	strTacGia = tacgia;
}
void Sach::setNhaXuatBan(string nhaxuatban)
{
	strNhaXuatBan = nhaxuatban;
}



void Sach::AddItem()
{
	Sach objSach;
	cout << "-----------Add Item - Them sach-----------" << endl;
	cout << "Nhap ten sach: ";
	fflush(stdin);
	getline(cin, objSach.strTenSach);
	cout << "Nhap ten tac gia: ";
	fflush(stdin);
	getline(cin, objSach.strTacGia);
	cout << "Nhap nha xuat ban: ";
	fflush(stdin);
	getline(cin, objSach.strNhaXuatBan);
	arrSach.push_back(objSach);
	arrFlag[index++] = 1;
}

void Sach::HideItem()
{
	cout << "-------------Hide Item - cho muon sach--------------" << endl;
	string hideBook;
	bool check1 = false;
MUON:
	cout << "Nhap ten sach can muon (phan biet chu Hoa - chu Thuong): ";
	fflush(stdin);
	getline(cin, hideBook);
	for(int i = 0; i < arrSach.size(); i++)
	{
		if(hideBook == arrSach[i].strTenSach)
		{
			arrFlag[i] = 0;
			check1 = true;
			cout << "MUON SACH THANH CONG!" << endl;
			break;
		}
	}
	if(check1 == false)
	{
		char reply;
		cout << "Ten sach muon khong co trong thu vien.\n Ban co muon nhap lai khong? (y = yes / n = no)" << endl;
		fflush(stdin);
		reply = getch();

		if(reply == 'y' || reply == 'Y')
			goto MUON;
	}
}

void Sach::ShowItem()
{
	cout << endl << "-------------show Item -  Tra sach----------------" << endl;
	string showBook;
	bool check1 = false;
TRA:
	cout << "Nhap ten sach can muon (phan biet chu Hoa - chu Thuong): ";
	fflush(stdin);
	getline(cin, showBook);
	for(int i = 0; i < arrSach.size(); i++)
	{
		if(showBook == arrSach[i].strTenSach)
		{
			arrFlag[i] = 1;
			check1 = true;
			cout << "TRA SACH THANH CONG!" << endl;
			break;
		}
	}
	if(check1 == false)
		cout << "Ten sach can tra SAI!" << endl;
}

void Sach::ShowListItems()
{
	cout << "===============SHOW LIST BOOK:" << endl;

	cout << setw(10) << "Ten Sach" << setw(22) << "Tac Gia" << setw(25) << "Nha Xuat Ban" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;

	for(int i = 0; i < arrSach.size(); i++)
	{
		if(arrFlag[i] == 1)
		{
			cout << arrSach[i].strTenSach<< "\t\t" << arrSach[i].strTacGia << "\t\t" << arrSach[i].strNhaXuatBan << endl;
		}	
	}
}

bool Sach::SearchItem()
{
	cout << "---------Search Item---------" << endl;
	string searchBook;
	cout << "Nhap ten sach can tim (phan biet chu Hoa - chu Thuong): ";
	fflush(stdin);
	getline(cin, searchBook);
	bool check1 = false;
	cout << setw(10) << "Ten Sach" << setw(22) << "Tac Gia" << setw(25) << "Nha Xuat Ban" << endl;
	for(int i = 0; i < arrSach.size(); i++)
	{
		if(searchBook == arrSach[i].strTenSach)
		{
			bool check1 = true;
			cout << arrSach[i].strTenSach<< "\t\t" << arrSach[i].strTacGia << "\t\t" << arrSach[i].strNhaXuatBan << endl;
		}
	}
	if(check1 == false)
		cout << "Ten tim kiem khong chinh xac!" << endl;
	return check1;
}

Sach::~Sach()
{

}