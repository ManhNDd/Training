#ifndef _SACH_
#define _SACH_

#include"K58Menu.h"
#include<string>
using namespace std;


class Sach : public K58Menu
{
private:
	string strTenSach;
	string strTacGia;
	string strNhaXuatBan;

public:
	int static soLuong;
	Sach();
	Sach(string tensach, string tacgia, string nhaxuatban);
	string getTenSach();
	string getTacGia();
	string getNhaXuatBan();
	void setTenSach(string tensach);
	void setTacGia(string tacgia);
	void setNhaXuatBan(string nhaxuatban);

	virtual void AddItem();
	virtual void HideItem();
	virtual void ShowItem();
	virtual void ShowListItems();
	virtual bool SearchItem();

	~Sach();
};

#endif