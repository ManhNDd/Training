#include"Sach.h"

int main()
{

	Sach objSach;
	objSach.ShowMenu();
	
	system("pause");
	return 0;
}
