﻿#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

#define MAX 100000

void NhapMang(int *a, int n)
{
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
}

void XuatMang(int *a, int n)
{
	for(int i = 0; i < n; i++)
	{
		printf("%d\n", a[i]);
	}
}

void TangGiaTriMotCap(int *a, int n, int x, int y)
{
	for(int i = x-1; i <= y-1; i++)
	{
		a[i]++;
	}
}

void TangGiaTriNhieuCap(int *a, int n, int m)
{
	int x, y;
	for(int i = 1; i <= m; i++)
	{
		scanf("%d %d", &x, &y);
		if(x > 0 && x <= y && y <= n)
		{
			for(int i = x-1; i <= y-1; i++)
			{
				a[i]++;
			}
		}
		else
		{
			printf("\nLỗi input");
		}

	}
}

void WriteOutput(int *a, int n)
{
	FILE* fp = fopen("output.txt", "wt");
	for(int i = 0; i < n; i++)
	{
		fprintf(fp, "%d\n", a[i]);
	}
	fclose(fp);
}

int main()
{
	freopen("input.txt", "r", stdin);
	int n, m;
	scanf("%d %d", &n, &m);
	if(n < MAX && m < MAX)
	{
		int *a = (int *)calloc(n, sizeof(int *));
		XuatMang(a,n);
		printf("\n----Output:\n");
		TangGiaTriNhieuCap(a, n, m);
		XuatMang(a, n);
		WriteOutput(a, n);
	}
	else
	{
		printf("\nLoi input [n, m < 100000]. Xin kiem tra lai!\n");
	}

	getch();
	return 0;
}