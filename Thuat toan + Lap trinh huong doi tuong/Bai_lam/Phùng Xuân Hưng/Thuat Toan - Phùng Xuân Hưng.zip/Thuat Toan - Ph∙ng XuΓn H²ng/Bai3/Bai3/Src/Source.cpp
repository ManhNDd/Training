﻿#include<stdio.h>
#include<conio.h>
#include<math.h>

#define LLI long long int

FILE* fp = fopen("output.txt", "wt");
void DigitSumAll(int nNumberCase)
{
	printf("Test case: %d\n", nNumberCase);
	for(int i = 1; i <= nNumberCase; i++)
	{
		LLI a, b;	     
		scanf("%lld %lld", &a, &b);
		LLI num = 0;
		if(a % 2 == 0)
			num = a;
		else
			num = a + 1;
		LLI sum = 0;
		for(; num <= b; num += 2)
		{
			LLI temp = num;
			while(temp != 0)
			{
				sum += temp % 10;
				temp = temp / 10;
			}
		}
		printf("\n%lld", sum);
		fprintf(fp, "%lld\n", sum);

	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	int nNumberCase;
	scanf("%d", &nNumberCase);		
	DigitSumAll(nNumberCase);

	getch();
	fclose(fp);
	return 0;
}