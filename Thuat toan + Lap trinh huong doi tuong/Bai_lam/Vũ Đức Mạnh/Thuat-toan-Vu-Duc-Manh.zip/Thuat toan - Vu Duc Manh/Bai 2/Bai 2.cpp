#include<stdio.h>
#include<string.h>
#include <stdlib.h>
FILE *fin = fopen("INPUT.txt", "r");
FILE *fout = fopen("OUTPUT.txt", "w");

struct WORD{
	char data[20];
	int count;
	int day;
};
WORD words[20000], listCounter[20000];
int day = 0;
int len = 0, lenListCounter = 0;

void readFile(){
	char s[80];
	while(!feof(fin)){
		fscanf(fin, "%s", s);
		if(strcmp(s, "<text>") == 0){
			day++;
		}
		words[len].count = 1;
		strcpy(words[len].data, s);
		words[len].day = day;
		len++;
	}
	fclose(fin);
}

void updateListCounter(char s[]){
	if(lenListCounter == 0){
		listCounter[lenListCounter].count = 1;
		strcpy(listCounter[lenListCounter].data, s);
		lenListCounter++;
	}else{
		bool flag = true; // danh dau da co trong list hay chua
		for(int i = 0; i < lenListCounter; i++){
			if(strcmp(listCounter[i].data, s) == 0){ // da co trong list
				listCounter[i].count++;
				flag = false;
			}
		}
		if(flag){ // chua co trong list
			listCounter[lenListCounter].count = 1;
			strcpy(listCounter[lenListCounter].data, s);
			lenListCounter++;
		}
	}
}

void createListCounter(int startDay, int endDay){
	for(int i = 0; i < len; i++){
		if(words[i].day >= startDay && words[i].day <= endDay){
			//add and update words to listCounter. ignore all tag and word length >= 4
			if((strcmp(words[i].data, "<text>") != 0) && (strcmp(words[i].data, "</text>") != 0)
				&& (strcmp(words[i].data, "<top") != 0) && (strlen(words[i].data) >= 4)){
					updateListCounter(words[i].data);
			}
		}
	}
}

void swap(WORD &a, WORD &b){
	WORD c; // c = a, a = b, b = c
	c.count = a.count; c.day = a.day; strcpy(c.data, a.data);
	a.count = b.count; a.day = b.day; strcpy(a.data, b.data);
	b.count = c.count; b.day = c.day; strcpy(b.data, c.data);
}

void sortListCounter(){
	for(int i = 0; i < lenListCounter - 1; i++){
		for(int j = i + 1; j < lenListCounter; j++){
			if(listCounter[i].count < listCounter[j].count){
				swap(listCounter[i], listCounter[j]);
			}else if(listCounter[i].count == listCounter[j].count){
				if(strcmp(listCounter[i].data, listCounter[j].data) > 0){
					swap(listCounter[i], listCounter[j]);
				}
			}
		}
	}
}

void printResult(int n){
	int dem = 1;
	int index = 0;
	fprintf(fout, "<top %d>\n", n);
	while(dem <= n && index < lenListCounter){
		if((index + 1 < lenListCounter) && (listCounter[index].count != listCounter[index + 1].count)){
			dem++;
		}
		fprintf(fout, "%s %d\n", listCounter[index].data, listCounter[index].count);
		index++;
	}
	fprintf(fout, "</top>\n");
	fclose(fout);
}

void processCounter(){
	for(int i = 0; i < len; i++){
		if(strcmp(words[i].data, "<top") == 0){
			int ntop = atoi(words[i + 1].data); // atoi: convert string to integer
			int endDay = words[i].day;
			int startDay = 0;
			if(endDay > 7){
				startDay = endDay - 7;
			}
			createListCounter(startDay, endDay);
			sortListCounter();
			printResult(ntop);
			lenListCounter = 0;
		}
	}
}

main(){
	readFile();
	createListCounter(1, 12);
	printf("Chieu dai cua words: %d\n", lenListCounter);
	sortListCounter();
	for(int i = 0; i < lenListCounter; i++){
		printf("%s,  %d\n", listCounter[i].data, listCounter[i].count);
	}
	system("pause");

}

