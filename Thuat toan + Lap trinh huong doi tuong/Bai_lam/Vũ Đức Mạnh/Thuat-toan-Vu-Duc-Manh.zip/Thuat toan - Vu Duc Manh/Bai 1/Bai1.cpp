#include<stdio.h>
#include<stdlib.h>

void execute(int n, int m, int *x, int *y, int *arr) {
	FILE *output;
	errno_t op;
	op = fopen_s(&output, "Output.txt", "wb");
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			if (i >= x[j] && i <= y[j]) {
				arr[i] += 1;
			}
		}
	}
	for (int i = 1; i <= n; i++)
	{
		printf("%d\n", arr[i]);
		fprintf_s(output, "%d\n", arr[i]);
	}
	fclose(output);
}
int main() {
	int n, *arr, i;
	int m, *x, *y, j;
	FILE *input;
	errno_t ip;
	ip = fopen_s(&input, "Input.txt", "wb");
	printf("Nhap so phan tu cua mang:");
	scanf_s("%d", &n);
	fprintf_s(input, "%d\t", n);
	arr = (int *)malloc(n * sizeof(int));
	for (i = 1; i <= n; i++) {
		arr[i] = 0;
	}
	printf("nhap so cap (x,y):");
	scanf_s("%d", &m);
	fprintf_s(input, "%d\n", m);
	x = (int *)malloc(m * sizeof(int));
	y = (int *)malloc(m * sizeof(int));
	for (j = 1; j <= m; j++) {
		printf("Nhap cap x,y thu %d:", j);
		scanf_s("%d%d", &x[j], &y[j]);
		fprintf_s(input, "%d\t%d\n", x[j], y[j]);
	}
	execute(n, m, x, y, arr);
	fclose(input);
	system("pause");
}
