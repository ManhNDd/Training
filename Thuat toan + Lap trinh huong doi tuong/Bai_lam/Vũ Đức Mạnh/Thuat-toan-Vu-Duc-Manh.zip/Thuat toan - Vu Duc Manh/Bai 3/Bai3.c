#include<stdio.h>
int Sum(int num) {
	int sum = 0;
	while (num > 0) {
		sum = sum + num % 10;
		num = num / 10;
	}
	return sum;
}

main() {
	int a, b, i, j;
	int s=0, s1=0;
	printf_s("Nhap a:");
	scanf_s("%d", &a);
	printf_s("Nhap b:");
	scanf_s("%d", &b);
	for (i = a; i <= b; i++) {
		s = s + Sum(i);
	}
	printf_s("The digit sum of the interval [%d,%d] should be:%d ", a, b, s);
	for (j = a; j <= b; j++) {
		if (j % 2 == 0) {
			s1 = s1 + Sum(j);
		}
		
	}
	printf_s("\nThe digit sum of even numbers of [%d,%d] should be:%d \n", a, b, s1);
	system("pause");
}