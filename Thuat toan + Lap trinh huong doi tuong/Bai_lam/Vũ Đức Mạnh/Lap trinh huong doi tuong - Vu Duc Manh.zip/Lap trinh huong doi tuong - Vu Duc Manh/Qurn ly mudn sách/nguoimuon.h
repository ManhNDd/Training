#include<iostream>
class nguoimuon {
public:
	std::string ten,lop,tensachmuon;
	nguoimuon(string ten, string lop, string tensachmuon);
};
nguoimuon::nguoimuon(string ten, string lop, string tensachmuon) {
	this->ten = ten;
	this->lop = lop;
	this->tensachmuon = tensachmuon;
}