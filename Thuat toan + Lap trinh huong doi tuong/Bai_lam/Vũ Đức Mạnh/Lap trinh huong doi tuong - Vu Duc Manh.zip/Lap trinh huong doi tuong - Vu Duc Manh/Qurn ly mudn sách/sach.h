#include<stdio.h>
#include<string>
#include<iostream>
using namespace std;
class sach {
private:
	string ten;
	string tacgia;
	string nxb;
	int trangthai;
public:
	sach(string ten, string tacgia, string nxb, int trangthai);
	void setten(string ten);
	string getten(void);
	void settacgia(string tacgia);
	string gettacgia(void);
	void setnxb(string nxb);
	string getnxb(void);
	void settrangthai(int trangthai);
	int gettrangthai(void);

};
void sach::setten(string ten) {
	this->ten = ten;
}
string sach::getten(void) {
	return ten;
}
void sach::settacgia(string tacgia) {
	this->tacgia = tacgia;
}
string sach::gettacgia(void) {
	return tacgia;
}
void sach::setnxb(string nxb) {
	this->nxb = nxb;
}
string sach::getnxb(void) {
	return nxb;
}
void sach::settrangthai(int trangthai) {
	this->trangthai = trangthai;
}
int sach::gettrangthai(void) {
	return trangthai;
}
sach::sach(string ten, string tacgia, string nxb, int trangthai) {
	this->ten = ten;
	this->tacgia = tacgia;
	this->nxb = nxb;
	this->trangthai = trangthai;
}