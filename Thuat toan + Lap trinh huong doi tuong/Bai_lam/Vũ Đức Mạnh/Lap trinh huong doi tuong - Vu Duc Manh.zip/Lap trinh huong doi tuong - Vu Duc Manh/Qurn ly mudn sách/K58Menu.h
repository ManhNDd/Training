#include<iostream>

class K58Menu {
public:
	K58Menu()
	{
		// khoi tao ban dau cho lop
	}
	void ShowMenu();
	~K58Menu()
	{
		// giai phong du lieu
	}
public:
	virtual void AddItem() = 0;
	virtual void HideItem() = 0;
	virtual void ShowItem() = 0;
	virtual void ShowListItems() = 0;
	virtual bool SearchItem() = 0;

};