#include"K58Menu.h"
#include"sach.h"
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include<vector>
#include"nguoimuon.h"
vector<sach> book;
vector<nguoimuon> people;
void K58Menu::ShowMenu()
{
	while (1)
	{
		cout << "\r\nMenu quan ly thu vien:\r\n1.Them sach\
                                    \r\n2.Hien danh sach sach co the muon\
                                    \r\n3.Cho muon sach\
                                    \r\n4.Tra sach\
                                    \r\n5.Tim kiem theo ten sach\
                                    \r\n6.Ket thuc\r\nChon:";
		int m_selected;
		cin >> m_selected;
		system("cls");		// thay cho ham clrscr()
		switch (m_selected)
		{
		case 1: AddItem();

			break;
		case 2: ShowListItems();

			break;
		case 3: HideItem();

			break;
		case 4: ShowItem();

			break;
		case 5: SearchItem();

			break;
		case 6: exit(0);
			break;
		default:
			cout << "Hay nhap lai:\r\n";
		}
	}
}

void K58Menu::AddItem()
{
}

void K58Menu::ShowListItems()
{

}

void K58Menu::HideItem()
{
	cout << "HideItem()";
}

void K58Menu::ShowItem()
{
	cout << "ShowItem()";
}

bool K58Menu::SearchItem()
{
	cout << "SearchItem()";
	return 0;
}
class QLMS :public K58Menu {
public:
	void AddItem();
	void HideItem();
	void ShowItem();
	void ShowListItems();
	bool SearchItem();
};
void QLMS::AddItem() {
	string ten, tacgia, nxb;
	int n;
	int trangthai = 0;//1:da muon,0:chua muon
	cout << "AddItem()\n";
	cout << "Nhap so sach muon them:";
	cin >> n;
	cin.ignore();
	for (int i = 0; i < n; i++) {
		cout << "Ten sach " << (i + 1) << ":";
		getline(cin, ten);
		cout << "Tac gia  " << (i + 1) << ":";
		getline(cin, tacgia);
		cout << "Nha xuat ban:" << (i + 1) << ":";
		getline(cin, nxb);
		sach add(ten, tacgia, nxb, trangthai);
		book.push_back(add);
	}

}
void QLMS::HideItem() {
	string tensach, tennguoimuon, lop;
	int dem = 0;
	cin.ignore();
	cout << "Nhap ten sach can muon:";
	getline(cin, tensach);
	for (int i = 0; i < book.size(); i++) {
		if (tensach.compare(book[i].getten()) == 0) {
			dem = 1;
			if (book[i].gettrangthai() != 0) {
				cout << "Sach da duoc muon" << endl;
			}
			else {
				cout << "Nhap ten nguoi muon:";
				getline(cin, tennguoimuon);
				cout << "Ten lop:";
				getline(cin, lop);
				nguoimuon pl(tennguoimuon, lop, tensach);
				people.push_back(pl);
				book[i].settrangthai(1);
			}
		}
	}
	if (dem == 0) {
		cout << "Khong tim thay !!";
	}
}
void QLMS::ShowItem() {
	string tensach;
	cin.ignore();
	cout << "Nhap ten sach:";
	getline(cin, tensach);
	for (int i = 0; i < book.size(); i++) {
		if (tensach.compare(book[i].getten()) == 0) {
			book[i].settrangthai(0);
			cout << "Tra sach thanh cong !";
		}
	}
}
void QLMS::ShowListItems() {
	cout << "ShowListItems()\n";
	int size = book.size();
	cout << "Ten sach\t\tTac gia\t\tNha xuat ban\t\tTrang thai\n";
	for (int i = 0; i < size; i++) {
		if (book[i].gettrangthai() == 0) {
			cout << book[i].getten() << "\t\t" << book[i].gettacgia() << "\t\t" << book[i].getnxb() << "\t\t" << book[i].gettrangthai() << "\n";
		}
	}
}
bool QLMS::SearchItem() {
	string tensach;
	int dem = 0;
	cin.ignore();
	cout << "Nhap ten sach can tim:";
	getline(cin, tensach);
	for (int i = 0; i < book.size(); i++) {
		if (tensach.compare(book[i].getten()) == 0) {
			cout <<"\rTac gia :"<<book[i].gettacgia()<<"\n\rNha xuat ban:"<<book[i].getnxb()<<"\n\rTrang thai:"<<book[i].gettrangthai();
			dem += 1;
			return true;
		}
	}
	if (dem == 0) {
		cout << "Khong tim thay";
		return false;
	}
}
int main() {
	QLMS a;
	a.ShowMenu();

}
