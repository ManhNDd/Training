#include<iostream>
using namespace std;
#include<conio.h>
#include<stdint.h>
#include<fstream>
long long getPhanNguyen(long long a) {
	return a / 10;
}

long long getPhanDu(long long a) {
	return a % 10;
}

long long tongPhanTu(long long temp, long long prevsum) {
	long long s = 0;
	if (getPhanDu(temp) == 0)
	{
		while (temp > 0) {
			s += getPhanDu(temp);
			temp = getPhanNguyen(temp);
		}
		return s;
	}
	else
	{
		return prevsum + 2;
	}
}
long long start(long long temp) {
	long long s = 0;
	while (temp > 0) {
		s += getPhanDu(temp);
		temp = getPhanNguyen(temp);
	}
	return s;
}
int main()
{
	int n;
	long long a, b, *kq;
	cin >> n;
	kq = new long long[n];
	for (int i = 0; i < n; i++)
	{
		cin >> a >> b;
		long long temp = a;
		long long s = 0;
		bool kt = true;
		long long tempsum;
		while (temp <= b)
		{
			if (kt == true)
			{
				if (temp % 2 == 0)
				{
					tempsum = start(temp);;
					s += tempsum;
					kt = false;
					temp += 2;
				}
				if (temp % 2 != 0)
				{
					temp++;
				}
			}
			if (kt == false)
			{
				tempsum = tongPhanTu(temp, tempsum);
				s += tempsum;
				temp += 2;
			}
		}
		kq[i] = s;
	}
	for (int i = 0; i < n; i++)
	{
		cout << kq[i] << "\n";
	}
	_getch();
}