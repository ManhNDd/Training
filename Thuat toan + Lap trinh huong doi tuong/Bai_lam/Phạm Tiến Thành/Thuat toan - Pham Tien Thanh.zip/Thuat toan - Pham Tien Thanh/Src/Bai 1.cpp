#include<iostream>
#include<fstream>
#include<conio.h>
using namespace std;

void input(int a[], int x[], int y[], int &n, int &m) {
	fstream infile;
	infile.open("input.txt", ios::in);
	infile >> n >> m;
	for (int i = 1; i <= n; i++) {
		a[i] = 0;
	}
	for (int i = 1; i <= m; i++) {
		infile >> x[i] >> y[i];
	}
}
void output(int a[], int n) {
	ofstream outfile;
	outfile.open("output.txt", ios::out);
	for (int i = 1; i <= n; i++)
		outfile << a[i] << endl;
}
void process(int a[], int x[], int y[], int m) {
	for (int i = 1; i <= m; i++) {
		for (int j = x[i]; j <= y[i]; j++) {
				a[j]++;
		}
	}
}
int main(){
	int n, m;
	int  *a, *x, *y;
	a = new int[n];
	x = new int[n];
	y = new int[n];
	input(a, x, y, n, m);
	process(a, x, y, m);
	output(a, n);
	delete a;
	delete x;
	delete y;
	_getch();
}