#include<iostream>
#include<fstream>
#include<ostream>
using namespace std;
#include<conio.h>
#include<string>
#include<stdint.h>
int inputText(string a[], string arrTop[])
{
	fstream infile;
	int i = 0, j = 0;
	string temp;
	infile.open("input.txt");
	while (!infile.eof())
	{
		string top;
		infile >> temp;
		if (temp.size() >= 4)
		{
			if (temp != "<text>" && temp != "</text>" && temp != "<top")
			{
				a[i] = temp;
				i++;
			}
		}
		if (temp == "<top")
		{
			infile >> top;
			a[i] = temp;
			arrTop[i] = top;
			i++;
		}
	}
	return i;
}
void processArray(int start, int end, bool markArray[], string wordArray[], string word[], int countArray[], int top)
{
	int countWord = start;
	for (int i = start; i < end; i++)
	{
		if (markArray[i] == true)
		{
			wordArray[countWord] = word[i];
			for (int j = start; j < end; j++)
			{
				if (wordArray[countWord] == word[j]){
					markArray[j] = false;
					countArray[countWord]++;
				}
			}
			countWord++;
		}
	}
	// sap xep theo thu tu giam dan cua so luan xuat hien
	for (int i = start; i < countWord - 1; i++){
		for (int j = i + 1; j < countWord; j++){
			if (countArray[i] < countArray[j]){
				int _tempcount = countArray[i];
				string _tempstring = wordArray[i];
				wordArray[i] = wordArray[j];
				countArray[i] = countArray[j];
				wordArray[j] = _tempstring;
				countArray[j] = _tempcount;
			}
		}
	}
	// xu ly top
	int max = countArray[start];
	int tempTop = top;
	for (int i = start; i < countWord; i++)
	{
		if (tempTop>1)
		{
			if (countArray[i] < max)
			{
				max = countArray[i];
				tempTop--;
			}
		}
	}
	// in ra
	ofstream outfile;
	outfile.open("output.txt", ios::app);
	outfile<< "<top " << top << ">\n";
	for (int i = start; i < countWord; i++)
	{
		if (countArray[i]>=max)
			outfile << wordArray[i] << " " << countArray[i] << "\n";
	}
	outfile << "</top>\n";
}

int main(){
	string word[10000];	// mang luu cac ky tu xuat hien
	bool markArray[10000];	// mang danh dau ky tu da duoc dem qua
	string wordArray[10000];	// mang luu cac ky tu sau khi da loc bo tu bi trung
	int countArray[10000];	// mang dem so lan xuat hien
	string arrTop[10000];	// mang luu so top
	int number = inputText(word, arrTop);
	for (int i = 0; i < number; i++){
		markArray[i] = true;
		countArray[i] = 0;
	}
	int now = 0, nowCountWord=0;
	for (int i = 0; i < number; i++)
	{
		if (word[i] == "<top")
		{
			int top = stoi(arrTop[i]);
			processArray(now, i, markArray, wordArray, word, countArray, top);
			now = i + 1;
		}
	}
	_getch();
}