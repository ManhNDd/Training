#include"K58Menu.h"
#include<iostream>
using namespace std;
#include<string>
#include<conio.h>
class Book
{
private:
	string book;
	string author;
	string publisher;
	bool available;
public:
	void setBook(string _bookName)
	{
		book = _bookName;
	}
	void setAuthor(string _authorName)
	{
		author = _authorName;
	}
	void setPublisher(string _publisherName)
	{
		publisher = _publisherName;
	}
	void setAvailable(bool _available)
	{
		available = _available;
	}
	string  getBook()
	{
		return book;
	}
	string  getAuthor()
	{
		return author;
	}
	string  getPublisher()
	{
		return publisher;
	}
	bool getAvailable()
	{
		return available;
	}
};

class Lib: public K58Menu
{
private:
	Book list[100];
	int number = 0;
public:
	void AddItem();	// them sach
	void ShowListItems();	// liet ke sach co the muon
	void HideItem();	// cho muon sach
	void ShowItem();	// tra sach
	bool SearchItem();	// tim sach
};

void Lib::AddItem()
{
	string _bookName, _authorName, _publisherName;
	fflush(stdin);
	cout << "Ten sach: ";
	getline(cin, _bookName);
	list[number].setBook(_bookName);
	cout << "Tac gia: ";
	getline(cin, _authorName);
	list[number].setAuthor(_authorName);
	cout << "Nha xuat ban: ";
	getline(cin, _publisherName);
	list[number].setPublisher(_publisherName);
	list[number].setAvailable(true);
	number++;
}
void Lib::ShowListItems()
{
	for (int i = 0; i < number; i++)
	{
		if (list[i].getAvailable()==true)
			cout << list[i].getBook() << "\t" << list[i].getAuthor() << "\t" << list[i].getPublisher() << endl;
	}
}
void Lib::HideItem()
{
	string _bookName;
	cout << "Ten sach: ";
	fflush(stdin);
	getline(cin, _bookName);
	for (int i = 0; i < number; i++)
	{
		if (list[i].getBook() == _bookName)
		{
			list[i].setAvailable(false);
			cout << "Da cho muon " << list[i].getBook() << "\t" << list[i].getAuthor() << "\t" << list[i].getPublisher() << endl;
		}
			
	}
}
void Lib::ShowItem()
{
	string _bookName;
	cout << "Ten sach: ";
	fflush(stdin);
	getline(cin, _bookName);
	for (int i = 0; i < number; i++)
	{
		if (list[i].getBook() == _bookName)
		{
			list[i].setAvailable(true);
			cout << "Da tra " << list[i].getBook() << "\t" << list[i].getAuthor() << "\t" << list[i].getPublisher() << endl;
		}
	}
			
}
bool Lib::SearchItem()
{
	string _bookName;
	cout << "Ten sach: ";
	fflush(stdin);
	getline(cin, _bookName);
	for (int i = 0; i < number; i++)
	{
		if (list[i].getBook() == _bookName){
			cout << list[i].getBook() << "\t" << list[i].getAuthor() << "\t" << list[i].getPublisher() << endl;
			return true;
		}		
	}
	return false;
}

int main()
{
	Lib a;
	a.ShowMenu();
}